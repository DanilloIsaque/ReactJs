import styled from "styled-components";

export const Menu = styled.nav`
    display:flex;
    height:50px;
    background-color:white;
    align-items:center;
    justify-content: space-around;
`;